#Groovy反编译APK,关键词过滤

写在开头

这次简单折腾一下Groovy语言，一方面是因为gradle就是该语言实现的，另外就是为了想了解下别人家的代码实现，但是茫茫大海哪里才是我要找的港湾啊，所以我也是被某位神秘大佬指引，直接写个相对来说要智能一点的筛选过滤方法，于是就诞生了该篇文章。本人经验不足，如有不足请各位大佬告知，鄙人定当虚心接受，努力改正。谢谢。

###1.Mac安装Groovy
命令行执行指令即可，brew install groovy

Groovy基础语法，自行百度吧，各种文档材料都有，我也就不写了，大部分还是类似于Java语法，Android或者Java服务器开发接入不会有什么难度。

###2.搭建Groovy开发环境
墙裂推荐一个Groovy开发模板，

Github地址是：https://github.com/pighead4u/groovy-app-template

直接把项目clone下来或者下载Zip包，本地使用AndroidStudio打开即可进行编辑，Coding。

比Eclipse安装插件高级太多了，对于长时间脱离Eclipse的开发者再切回Eclipse写代码，简直想以头抢地尔，代码提示缓慢，快捷键不同让我直接想放弃......

####3.需要注意的一点就是需要导入ApkTool.jar包进行编译
见图说话

![](1.png)

####4.阅读ApkTool.jar文件

使用JD-GUI工具直接打开Apktool.jar文件

![](2.png)

上图指出了apktool.jar入口文件主要位置



先回忆下在命令行上反编译指令是啥？？？？

![](3.png)

命令行反编译指令：apktool d test.apk，桥豆麻袋，这个d怎么这么熟悉，卧槽，这不就是我们在命令行反编译输入的参数么。原来最后的执行在这.....


####5.编写反编译Groovy代码，对文件进行关键字筛选

```
import brut.androlib.ApkDecoder
import brut.androlib.err.CantFindFrameworkResException
import brut.androlib.err.InFileNotFoundException
import brut.androlib.err.OutDirExistsException
import brut.directory.DirectoryException

class DecompileApk {
    public static String ORIGIN_FILE_PATH = "apk/"
    public static String OUT_FILE_PATH = "apk/outDir/"
    public static String KEY_WORD = "retrofit"

    static def decodeApk = { File file ->
//		String outName = APK_NAME + ".out_" + new Date().format("yyyyMMddHHmmss")
        String outName = file.getName() + ".out"
        ApkDecoder decoder = new ApkDecoder()
        File outDir = new File(OUT_FILE_PATH + outName)
        decoder.setOutDir(outDir)
        if (outDir.exists()) {
            outDir.deleteDir()
        }
        decoder.setApkFile(file)
        try {
            decoder.decode()
        } catch (IOException ex) {
            println("Could not modify file. Please ensure you have permission.")
            System.exit(1)
        } catch (OutDirExistsException ex) {
            println("Destination directory (" + outDir.getAbsolutePath() + ") already exists. Use -f switch if you want to overwrite it.")
            System.exit(1)
        } catch (InFileNotFoundException ex) {
            println("Input file (" + APK_NAME + ") was not found or was not readable.")
            System.exit(1)
        } catch (CantFindFrameworkResException ex) {
            println("Can't find framework resources for package of id: " + String.valueOf(ex.getPkgId()) + ". You must install proper framework files, see project website for more info.")
            System.exit(1)
        } catch (DirectoryException ex) {
            println("Could not modify internal dex files. Please ensure you have permission.")
            System.exit(1)
        }
        outDir
    }

    static def searchKeyWordFromDecodeApkFile = { File outDir ->
        StringBuilder sb = new StringBuilder()
        outDir.eachFileRecurse { file ->
            if (file.getAbsolutePath().endsWith(".smali")) {
                def contain = false
                ((File) file).eachLine { line ->
                    if (line.toLowerCase().contains(KEY_WORD.toLowerCase())) {
                        contain = true
                    }
                }
                if (contain) {
                    sb.append(file.getAbsolutePath())
                    sb.append("\n")
                }
            }
        }
        sb.toString()
    }

    static def save2File = { String dir, String name, String content ->
        if (content.length() > 0) {
            String fileName = dir + "/" + name + "_" + KEY_WORD + ".txt"
            new File(fileName).write(content)
            Process p = ("open " + fileName).execute()
            println "${p.text}"
        }
    }

    static def decodeMultiApk = {
        File apkPath = new File(ORIGIN_FILE_PATH)
        apkPath.eachFile { File apkFile ->
            if (!apkFile.isDirectory() && apkFile.getAbsolutePath().endsWith(".apk")) {
                Thread.start {
                    println(Thread.currentThread())
                    File outDirFile = decodeApk.call(apkFile)
                    String content = searchKeyWordFromDecodeApkFile.call(outDirFile)
                    save2File.call(outDirFile.getAbsolutePath(), apkFile.getName(), content)
                    println "======================Success======================"
                }
            }
        }
    }

    public static void main(String[] args) {
        decodeMultiApk()
    }
}

```

代码不多，实现也简单，执行流程我都不好意思说出来了，哈哈哈，大家自行阅读吧

有几点需要注意的是：

(1) 反编译精华主要是ApkDecoder类,阅读apktool.jar源码，你会获得更多，建议参考第4点

(2) 在闭包中调用闭包的格式是：闭包名.call(参数....) 例如代码中 decodeApk.call(apkFile)

(3) Groovy对一些常用操作进行再次封装，提供了更简便的Api进行调用，大部分实现也是基于闭包实现的，例如文件操作，开启线程等。

####6.Groovy如何运行

还记得你写第一个Java程序怎么运行的么？？？

是不是直接右键运行main函数

这里也是！！！！回归初心


####7.编译结果及包含关键词所在文件：

![](4.jpg)